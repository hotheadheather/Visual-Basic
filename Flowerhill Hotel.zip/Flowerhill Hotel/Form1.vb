﻿'Project Name: Flowerhill Project
'Project purpose: calculate the hotel bill
'Author: Heather Whittlesey

Option Explicit On
Option Infer Off
Option Strict On



Public Class Form1
    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        'Exit the App
        Me.Close()

    End Sub

    Private Sub btn_Calc_Click(sender As Object, e As EventArgs) Handles btn_Calc.Click
        'Declare variables
        Dim dblRoomCost As Double = 255.5
        Dim intRooms As Integer
        Dim intDays As Integer
        Dim intAdults As Integer
        Dim intChildren As Integer
        Const dblFee As Double = 22.5
        Const dblTaxRate As Double = 0.1075
        Dim dblTotTax As Double
        Dim dblTotal As Double
        Dim dblTotFee As Double
        Dim dblRoomsTot As Double
        Dim dblSubTot As Double


        'store input as variables
        Integer.TryParse(txt_rooms.Text, intRooms)
        Integer.TryParse(txt_days.Text, intDays)

        'perform calculations

        dblTotFee = (dblFee * intRooms) + (dblFee * intDays)
        dblSubTot = intRooms * 255.5
        dblTotTax = dblTaxRate * (dblSubTot + dblTotFee)
        dblTotal = (dblSubTot + dblTotTax + dblTotFee)



        'display calculated results and set focus
        txt_Total.Text = dblTotal.ToString("c")
        txt_TotFee.Text = dblTotFee.ToString("c")
        txt_TaxRate.Text = dblTotTax.ToString("c")
        txt_SubTot.Text = dblSubTot.ToString("c")




    End Sub

    Private Sub txt_clear_Click(sender As Object, e As EventArgs) Handles txt_clear.Click

        txt_rooms.Text = ""
        txt_days.Text = ""
        txt_adult.Text = ""
        txt_children.Text = ""
        txt_TaxRate.Text = ""
        txt_SubTot.Text = ""
        txt_TotFee.Text = ""
        txt_Total.Text = ""
        txt_rooms.Focus()

    End Sub
End Class
