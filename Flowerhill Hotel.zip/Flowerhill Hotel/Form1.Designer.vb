﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txt_rooms = New System.Windows.Forms.TextBox()
        Me.txt_days = New System.Windows.Forms.TextBox()
        Me.txt_adult = New System.Windows.Forms.TextBox()
        Me.txt_children = New System.Windows.Forms.TextBox()
        Me.txt_TaxRate = New System.Windows.Forms.TextBox()
        Me.txt_Total = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btn_Calc = New System.Windows.Forms.Button()
        Me.btn_Exit = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txt_TotFee = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txt_SubTot = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txt_clear = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(61, 67)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(87, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Number of roo&ms"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(184, 67)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Number of &days"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(61, 120)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Number of &adults"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(184, 120)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(96, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Number of &children"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(147, 94)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(36, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Ta&xes"
        '
        'txt_rooms
        '
        Me.txt_rooms.Location = New System.Drawing.Point(64, 83)
        Me.txt_rooms.Name = "txt_rooms"
        Me.txt_rooms.Size = New System.Drawing.Size(100, 20)
        Me.txt_rooms.TabIndex = 6
        '
        'txt_days
        '
        Me.txt_days.Location = New System.Drawing.Point(187, 83)
        Me.txt_days.Name = "txt_days"
        Me.txt_days.Size = New System.Drawing.Size(100, 20)
        Me.txt_days.TabIndex = 7
        '
        'txt_adult
        '
        Me.txt_adult.Location = New System.Drawing.Point(64, 136)
        Me.txt_adult.Name = "txt_adult"
        Me.txt_adult.Size = New System.Drawing.Size(100, 20)
        Me.txt_adult.TabIndex = 8
        '
        'txt_children
        '
        Me.txt_children.Location = New System.Drawing.Point(187, 136)
        Me.txt_children.Name = "txt_children"
        Me.txt_children.Size = New System.Drawing.Size(100, 20)
        Me.txt_children.TabIndex = 9
        '
        'txt_TaxRate
        '
        Me.txt_TaxRate.BackColor = System.Drawing.SystemColors.Menu
        Me.txt_TaxRate.Location = New System.Drawing.Point(150, 110)
        Me.txt_TaxRate.Name = "txt_TaxRate"
        Me.txt_TaxRate.Size = New System.Drawing.Size(100, 20)
        Me.txt_TaxRate.TabIndex = 11
        '
        'txt_Total
        '
        Me.txt_Total.BackColor = System.Drawing.SystemColors.Menu
        Me.txt_Total.Location = New System.Drawing.Point(150, 152)
        Me.txt_Total.Name = "txt_Total"
        Me.txt_Total.Size = New System.Drawing.Size(100, 20)
        Me.txt_Total.TabIndex = 12
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(147, 136)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(31, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "&Total"
        '
        'btn_Calc
        '
        Me.btn_Calc.Location = New System.Drawing.Point(32, 29)
        Me.btn_Calc.Name = "btn_Calc"
        Me.btn_Calc.Size = New System.Drawing.Size(75, 23)
        Me.btn_Calc.TabIndex = 14
        Me.btn_Calc.Text = "Calculate"
        Me.btn_Calc.UseVisualStyleBackColor = True
        '
        'btn_Exit
        '
        Me.btn_Exit.Location = New System.Drawing.Point(32, 149)
        Me.btn_Exit.Name = "btn_Exit"
        Me.btn_Exit.Size = New System.Drawing.Size(75, 23)
        Me.btn_Exit.TabIndex = 15
        Me.btn_Exit.Text = "Exit"
        Me.btn_Exit.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("AR BLANCA", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(87, 25)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(197, 30)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Flowerhill Resort"
        '
        'txt_TotFee
        '
        Me.txt_TotFee.BackColor = System.Drawing.SystemColors.Menu
        Me.txt_TotFee.Location = New System.Drawing.Point(150, 71)
        Me.txt_TotFee.Name = "txt_TotFee"
        Me.txt_TotFee.Size = New System.Drawing.Size(100, 20)
        Me.txt_TotFee.TabIndex = 17
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(147, 55)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(83, 13)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "Total Resort &fee"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txt_clear)
        Me.Panel1.Controls.Add(Me.btn_Exit)
        Me.Panel1.Controls.Add(Me.txt_SubTot)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.btn_Calc)
        Me.Panel1.Controls.Add(Me.txt_TotFee)
        Me.Panel1.Controls.Add(Me.txt_Total)
        Me.Panel1.Controls.Add(Me.txt_TaxRate)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Location = New System.Drawing.Point(32, 171)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(294, 199)
        Me.Panel1.TabIndex = 19
        '
        'txt_SubTot
        '
        Me.txt_SubTot.BackColor = System.Drawing.SystemColors.Menu
        Me.txt_SubTot.Location = New System.Drawing.Point(150, 32)
        Me.txt_SubTot.Name = "txt_SubTot"
        Me.txt_SubTot.Size = New System.Drawing.Size(100, 20)
        Me.txt_SubTot.TabIndex = 20
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(147, 16)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(46, 13)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Su&btotal"
        '
        'txt_clear
        '
        Me.txt_clear.Location = New System.Drawing.Point(32, 89)
        Me.txt_clear.Name = "txt_clear"
        Me.txt_clear.Size = New System.Drawing.Size(75, 23)
        Me.txt_clear.TabIndex = 20
        Me.txt_clear.Text = "Clear"
        Me.txt_clear.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txt_children)
        Me.Controls.Add(Me.txt_adult)
        Me.Controls.Add(Me.txt_days)
        Me.Controls.Add(Me.txt_rooms)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form1"
        Me.Text = "Flowerhill Resort"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txt_rooms As TextBox
    Friend WithEvents txt_days As TextBox
    Friend WithEvents txt_adult As TextBox
    Friend WithEvents txt_children As TextBox
    Friend WithEvents txt_TaxRate As TextBox
    Friend WithEvents txt_Total As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents btn_Calc As Button
    Friend WithEvents btn_Exit As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents txt_TotFee As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents txt_SubTot As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txt_clear As Button
End Class
