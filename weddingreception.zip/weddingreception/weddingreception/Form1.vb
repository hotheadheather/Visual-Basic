﻿'Wedding reception is an app that allows you to calculate how many rectangular and 
'round tables you need according To the type of guest and capacity of tables.
'Author: Heather Whittlesey
'10-5-2019

Option Strict On
Option Explicit On
Option Infer Off

Public Class txt_totInv
    Private Sub btn_exit_Click(sender As Object, e As EventArgs) Handles btn_exit.Click
        Me.Close()
    End Sub

    Private Sub btn_clear_Click(sender As Object, e As EventArgs) Handles btn_clear.Click
        txt_brideAttend.Text = ""
        txt_guestAttend.Text = ""
        txt_rect.Text = ""
        txt_round.Text = ""
        txt_totTables.Text = ""
        txt_roundTableCost.Text = ""
        txt_rectTableCost.Text = ""
        txt_totTabCost.Text = ""
        txt_totInvoice.Text = ""

        txt_brideAttend.Focus()

    End Sub

    Private Sub btn_calc_Click(sender As Object, e As EventArgs) Handles btn_calc.Click
        Dim intBride As Integer
        Dim intGuest As Integer
        Dim intRect As Integer = 0
        Dim intRound As Integer = 0
        Dim inttotTables As Integer
        Dim intRemainder As Integer
        Dim dblrecttabcost As Double
        Dim dblroundtabcost As Double
        Dim dbltottablecost As Double
        Dim dbldiscount As Double
        Dim dbltotdiscount As Double
        Dim dbltotalInvoice As Double


        Integer.TryParse(txt_brideAttend.Text, intBride)
        Integer.TryParse(txt_guestAttend.Text, intGuest)
        Double.TryParse(txt_rectTableCost.Text, dblrecttabcost)
        Double.TryParse(txt_roundTableCost.Text, dblroundtabcost)
        Double.TryParse(txt_totInvoice.Text, dbltotalInvoice)





        Try
            intRect = intBride \ 10
            intRemainder = intBride Mod 10
            If intRemainder <> 0 Then
                intRect += 1

            End If

            intRound = intGuest \ 8
            intRemainder = intGuest Mod 8
            If intRemainder <> 0 Then
                intRound += 1

            End If

            dblrecttabcost = intRect * 100
            dblroundtabcost = intRound * 75
            dbltottablecost = dblrecttabcost + dblroundtabcost
            'dbltotdiscount = dbltottablecost - dbldiscount


            inttotTables = intRect + intRound
            txt_rect.Text = intRect.ToString()
            txt_round.Text = intRound.ToString()
            txt_rectTableCost.Text = dblrecttabcost.ToString("c")
            txt_roundTableCost.Text = dblroundtabcost.ToString("c")
            txt_totTables.Text = inttotTables.ToString
            txt_totTabCost.Text = dbltottablecost.ToString("c")






            If dbltottablecost >= 5000 Then
                dbldiscount = 0.1
            Else
                dbldiscount = 0.0
            End If

            If dbltottablecost >= 5000 Then
                dbltotdiscount = dbltottablecost - dbltotalInvoice
            Else
                dbltotdiscount = 0.0

            End If

            dbltotdiscount = dbltottablecost * dbldiscount
            dbltotalInvoice = dbltottablecost - dbltotdiscount
            txt_totInvoice.Text = dbltotalInvoice.ToString("C2")





        Catch ex As Exception
            MessageBox.Show("You need to fill out the entire form")

        End Try

    End Sub


End Class
