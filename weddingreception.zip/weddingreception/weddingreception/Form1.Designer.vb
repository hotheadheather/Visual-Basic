﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class txt_totInv
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txt_brideAttend = New System.Windows.Forms.TextBox()
        Me.txt_round = New System.Windows.Forms.TextBox()
        Me.txt_rect = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txt = New System.Windows.Forms.Label()
        Me.txt_guestAttend = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txt_totTables = New System.Windows.Forms.TextBox()
        Me.btn_calc = New System.Windows.Forms.Button()
        Me.btn_clear = New System.Windows.Forms.Button()
        Me.btn_exit = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txt_rectTableCost = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txt_roundTableCost = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txt_totTabCost = New System.Windows.Forms.TextBox()
        Me.txt_totInvoice = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(229, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(102, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Wedding Reception"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(124, 31)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Bridal Party"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(359, 31)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Guests"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(39, 122)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(121, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Rectangular Tables (10)"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(299, 122)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(89, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Round Tables (8)"
        '
        'txt_brideAttend
        '
        Me.txt_brideAttend.Location = New System.Drawing.Point(164, 60)
        Me.txt_brideAttend.Name = "txt_brideAttend"
        Me.txt_brideAttend.Size = New System.Drawing.Size(100, 20)
        Me.txt_brideAttend.TabIndex = 5
        '
        'txt_round
        '
        Me.txt_round.BackColor = System.Drawing.SystemColors.Menu
        Me.txt_round.Location = New System.Drawing.Point(394, 119)
        Me.txt_round.Name = "txt_round"
        Me.txt_round.Size = New System.Drawing.Size(100, 20)
        Me.txt_round.TabIndex = 11
        '
        'txt_rect
        '
        Me.txt_rect.BackColor = System.Drawing.SystemColors.Menu
        Me.txt_rect.Location = New System.Drawing.Point(164, 119)
        Me.txt_rect.Name = "txt_rect"
        Me.txt_rect.Size = New System.Drawing.Size(100, 20)
        Me.txt_rect.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(96, 67)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(62, 13)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "&Attendance"
        '
        'txt
        '
        Me.txt.AutoSize = True
        Me.txt.Location = New System.Drawing.Point(323, 64)
        Me.txt.Name = "txt"
        Me.txt.Size = New System.Drawing.Size(62, 13)
        Me.txt.TabIndex = 6
        Me.txt.Text = "A&ttendance"
        '
        'txt_guestAttend
        '
        Me.txt_guestAttend.Location = New System.Drawing.Point(391, 61)
        Me.txt_guestAttend.Name = "txt_guestAttend"
        Me.txt_guestAttend.Size = New System.Drawing.Size(100, 20)
        Me.txt_guestAttend.TabIndex = 7
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(51, 235)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(107, 13)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Total Tables Needed"
        '
        'txt_totTables
        '
        Me.txt_totTables.BackColor = System.Drawing.SystemColors.Menu
        Me.txt_totTables.Location = New System.Drawing.Point(164, 231)
        Me.txt_totTables.Name = "txt_totTables"
        Me.txt_totTables.Size = New System.Drawing.Size(100, 20)
        Me.txt_totTables.TabIndex = 17
        '
        'btn_calc
        '
        Me.btn_calc.Location = New System.Drawing.Point(99, 362)
        Me.btn_calc.Name = "btn_calc"
        Me.btn_calc.Size = New System.Drawing.Size(75, 23)
        Me.btn_calc.TabIndex = 25
        Me.btn_calc.Text = "Calculate"
        Me.btn_calc.UseVisualStyleBackColor = True
        '
        'btn_clear
        '
        Me.btn_clear.Location = New System.Drawing.Point(249, 362)
        Me.btn_clear.Name = "btn_clear"
        Me.btn_clear.Size = New System.Drawing.Size(75, 23)
        Me.btn_clear.TabIndex = 26
        Me.btn_clear.Text = "Clear"
        Me.btn_clear.UseVisualStyleBackColor = True
        '
        'btn_exit
        '
        Me.btn_exit.Location = New System.Drawing.Point(394, 362)
        Me.btn_exit.Name = "btn_exit"
        Me.btn_exit.Size = New System.Drawing.Size(75, 23)
        Me.btn_exit.TabIndex = 0
        Me.btn_exit.Text = "Exit"
        Me.btn_exit.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(39, 178)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(119, 13)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Rectangular Table Cost"
        '
        'txt_rectTableCost
        '
        Me.txt_rectTableCost.BackColor = System.Drawing.SystemColors.MenuBar
        Me.txt_rectTableCost.Location = New System.Drawing.Point(164, 175)
        Me.txt_rectTableCost.Name = "txt_rectTableCost"
        Me.txt_rectTableCost.Size = New System.Drawing.Size(100, 20)
        Me.txt_rectTableCost.TabIndex = 13
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(299, 178)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(93, 13)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "Round Table Cost"
        '
        'txt_roundTableCost
        '
        Me.txt_roundTableCost.BackColor = System.Drawing.SystemColors.Menu
        Me.txt_roundTableCost.Location = New System.Drawing.Point(394, 175)
        Me.txt_roundTableCost.Name = "txt_roundTableCost"
        Me.txt_roundTableCost.Size = New System.Drawing.Size(100, 20)
        Me.txt_roundTableCost.TabIndex = 15
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(300, 231)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(85, 13)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Total Table Cost"
        '
        'txt_totTabCost
        '
        Me.txt_totTabCost.BackColor = System.Drawing.SystemColors.Menu
        Me.txt_totTabCost.Location = New System.Drawing.Point(394, 228)
        Me.txt_totTabCost.Name = "txt_totTabCost"
        Me.txt_totTabCost.Size = New System.Drawing.Size(100, 20)
        Me.txt_totTabCost.TabIndex = 19
        '
        'txt_totInvoice
        '
        Me.txt_totInvoice.BackColor = System.Drawing.SystemColors.Menu
        Me.txt_totInvoice.Location = New System.Drawing.Point(314, 298)
        Me.txt_totInvoice.Name = "txt_totInvoice"
        Me.txt_totInvoice.Size = New System.Drawing.Size(100, 20)
        Me.txt_totInvoice.TabIndex = 24
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(169, 301)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(136, 13)
        Me.Label12.TabIndex = 23
        Me.Label12.Text = "Total Invoice with Discount"
        '
        'txt_totInv
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(540, 450)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.txt_totInvoice)
        Me.Controls.Add(Me.txt_totTabCost)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txt_roundTableCost)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txt_rectTableCost)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.btn_exit)
        Me.Controls.Add(Me.btn_clear)
        Me.Controls.Add(Me.btn_calc)
        Me.Controls.Add(Me.txt_totTables)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txt)
        Me.Controls.Add(Me.txt_guestAttend)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txt_rect)
        Me.Controls.Add(Me.txt_round)
        Me.Controls.Add(Me.txt_brideAttend)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "txt_totInv"
        Me.Text = "Wedding Reception"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txt_brideAttend As TextBox
    Friend WithEvents txt_round As TextBox
    Friend WithEvents txt_rect As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txt As Label
    Friend WithEvents txt_guestAttend As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txt_totTables As TextBox
    Friend WithEvents btn_calc As Button
    Friend WithEvents btn_clear As Button
    Friend WithEvents btn_exit As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents txt_rectTableCost As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txt_roundTableCost As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txt_totTabCost As TextBox
    Friend WithEvents txt_totInvoice As TextBox
    Friend WithEvents Label12 As Label
End Class
